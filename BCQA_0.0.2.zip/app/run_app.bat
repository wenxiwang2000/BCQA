@echo off
:: Helper script to run the Heatmap Cell Quality Assay Streamlit app on Windows.

:: Change to the directory of this script
cd /d "%~dp0"

:: Create a virtual environment if it doesn't exist
if not exist .venv (
    echo Creating virtual environment...
    python -m venv .venv
)

:: Activate the virtual environment
call .venv\Scripts\activate.bat

:: Install dependencies
echo Installing Python dependencies...
python -m pip install --upgrade pip > NUL 2>&1
python -m pip install -r requirements.txt

:: Start the Streamlit app
echo Starting Streamlit app...
streamlit run main.py